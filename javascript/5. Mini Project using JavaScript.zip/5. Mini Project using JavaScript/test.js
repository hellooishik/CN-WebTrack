var a = 10 ;
if(a >= 10){
    var b = 2;
}else{
    var c = 30;
}
console.log(a , b , c)